--
-- Data model for acs-authentication
--
-- $Id: acs-authentication-create.sql,v 1.1 2003/09/08 15:59:43 lars Exp $
--

\i batch-job-tables-create.sql


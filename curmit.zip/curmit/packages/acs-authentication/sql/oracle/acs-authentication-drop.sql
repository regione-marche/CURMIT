--
-- Drop script for acs-authentication
--
-- $Id: acs-authentication-drop.sql,v 1.1 2003/09/08 15:59:42 lars Exp $
--

@@ batch-job-tables-drop.sql


drop sequence auth_batch_jobs_job_id_seq;
drop sequence auth_batch_job_entry_id_seq;

drop table auth_batch_job_entries;

drop table auth_batch_jobs;

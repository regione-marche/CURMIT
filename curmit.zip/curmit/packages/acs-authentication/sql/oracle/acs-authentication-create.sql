--
-- Data model for acs-authentication
--
-- $Id: acs-authentication-create.sql,v 1.1 2003/09/08 15:59:42 lars Exp $
--

@@ batch-job-tables-create.sql


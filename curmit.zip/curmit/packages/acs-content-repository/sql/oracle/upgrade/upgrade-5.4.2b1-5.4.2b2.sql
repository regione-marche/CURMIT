-- 
-- 
-- 
-- @author Dave Bauer (dave@thedesignexperience.org)
-- @creation-date 2008-05-13
-- @cvs-id $Id: upgrade-5.4.2b1-5.4.2b2.sql,v 1.2 2008/06/07 20:28:47 donb Exp $
--

drop table cr_doc_filter;
-- 
-- 
-- 
-- @author Rocael Hernandez (roc@viaro.net)
-- @creation-date 2004-09-02
-- @arch-tag: d5184853-cbe4-4860-94a8-9a60587b36eb
-- @cvs-id $Id: upgrade-5.1.2d6-5.1.2d7.sql,v 1.3 2005/02/24 13:32:58 jeffd Exp $
--

-- create index cr_items_name on cr_items(name);
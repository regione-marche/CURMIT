create or replace view content_item_globals as
    select -100 as c_root_folder_id
    from dual;


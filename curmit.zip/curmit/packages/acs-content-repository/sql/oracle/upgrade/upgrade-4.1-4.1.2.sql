-- packages/acs-content-repository/sql/upgrade/upgrade-4.1-4.1.2.sql
--
-- @author teeters@arsdigita.com
-- @creation-date 2000-03-06
-- @cvs-id $Id: upgrade-4.1-4.1.2.sql,v 1.1 2001/04/05 18:55:28 donb Exp $
--

-- upgrade script.
-- reload all packages.
-- This should be run manually.

@../../../acs-content-repository/sql/packages-create.sql


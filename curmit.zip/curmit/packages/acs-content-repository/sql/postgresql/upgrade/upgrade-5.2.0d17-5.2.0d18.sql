select define_function_args('content_item__set_live_revision','revision_id,publish_status;ready');

-- Ensure that the data model is up-to-date before compiling packages

-- \i content-util.sql
\i content-update.sql

\i content-type.sql
\i content-item.sql
\i content-revision.sql
\i content-symlink.sql
\i content-extlink.sql
\i content-folder.sql
\i content-template.sql
\i content-keyword.sql



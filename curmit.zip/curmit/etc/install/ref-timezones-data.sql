-- packages/ref-timezones/sql/oracle/ref-timezone-data.sql
--
-- Part of the timezone reference data
-- 
-- @cvs-id $Id: ref-timezones-data.sql,v 1.1 2003/09/04 16:51:26 joela Exp $

insert into timezones values (1,'Africa/Abidjan','+000000');     
insert into timezones values (2,'Africa/Accra','+000000');       
